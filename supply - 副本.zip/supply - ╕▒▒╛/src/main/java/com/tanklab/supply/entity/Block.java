package com.tanklab.supply.entity;

public class Block {
}
