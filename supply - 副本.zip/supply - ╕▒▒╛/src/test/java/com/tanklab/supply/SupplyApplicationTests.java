package com.tanklab.supply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
