<template>
    <router-link to="/">
        <div class="logo">登出</div>
    </router-link>
</template>

<style scoped>
.logo {
    font-weight: bold;
}
</style>
