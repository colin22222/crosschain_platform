declare namespace API {
    
    /** 地址详细信息参数 */
    type AddressDetailParams = {
        id: string;
    };

    /** 地址详细信息 */
    type AddressDetailResponse = {
        id: string;
    };
}