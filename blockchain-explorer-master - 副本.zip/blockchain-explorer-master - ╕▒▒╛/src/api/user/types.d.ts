declare namespace API {

    /** 交易列表参数 */
    type UserSMKeyPairsParams = undefined;

    /** 交易列表 */
    type UserSMKeyPairsResponse = {
        priv: string;
        pub: string;
    };
}