type AddressMap = {
    label: string;
    key: string;
}

export type AddressDescMap = Array<AddressMap>